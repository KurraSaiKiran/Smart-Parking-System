export interface ParkingSlot {
  id: string;
  number: number;
  isOccupied: boolean;
  isReserved: boolean;
  reservedBy?: string;
  reservationTime?: string;
  type: 'standard' | 'premium' | 'disabled';
  floor: number;
}

export interface Reservation {
  id: string;
  slotId: string;
  userId: string;
  startTime: string;
  endTime: string;
  status: 'active' | 'completed' | 'cancelled';
  price: number;
  paymentStatus: 'pending' | 'paid';
}

export interface User {
  id: string;
  name: string;
  email: string;
  reservations: string[];
  role: 'user' | 'admin';
  credits: number;
}

export interface ParkingRate {
  type: 'standard' | 'premium' | 'disabled';
  baseRate: number;
  hourlyRate: number;
}