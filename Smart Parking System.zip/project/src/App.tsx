import React from 'react';
import { ParkingGrid } from './components/ParkingGrid';
import { ReservationForm } from './components/ReservationForm';
import { Stats } from './components/Stats';
import { Auth } from './components/Auth';
import { ReservationHistory } from './components/ReservationHistory';
import { ParkingSquare } from 'lucide-react';
import { useStore } from './store/useStore';

function App() {
  const { slots, selectedSlot, setSelectedSlot } = useStore();

  const handleSlotClick = (slot: ParkingSlot) => {
    if (!slot.isOccupied && !slot.isReserved) {
      setSelectedSlot(slot);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <ParkingSquare className="w-8 h-8 text-blue-600 mr-3" />
              <h1 className="text-3xl font-bold text-gray-900">
                Smart Parking System
              </h1>
            </div>
            <Auth />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <Stats slots={slots} />
        
        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Parking Layout</h2>
              <ParkingGrid slots={slots} onSlotClick={handleSlotClick} />
            </div>
          </div>
          
          <div className="col-span-1">
            <ReservationHistory />
          </div>
        </div>

        {selectedSlot && (
          <ReservationForm
            selectedSlot={selectedSlot}
            onClose={() => setSelectedSlot(null)}
          />
        )}
      </main>
    </div>
  );
}

export default App;