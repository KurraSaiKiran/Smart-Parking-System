import { create } from 'zustand';
import { ParkingSlot, Reservation, User, ParkingRate } from '../types';
import { generateMockSlots } from '../utils/mockData';

interface State {
  slots: ParkingSlot[];
  reservations: Reservation[];
  currentUser: User | null;
  parkingRates: ParkingRate[];
  selectedSlot: ParkingSlot | null;
  setSelectedSlot: (slot: ParkingSlot | null) => void;
  createReservation: (reservation: Omit<Reservation, 'id' | 'status' | 'paymentStatus'>) => void;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useStore = create<State>((set) => ({
  slots: generateMockSlots(),
  reservations: [],
  currentUser: null,
  parkingRates: [
    { type: 'standard', baseRate: 5, hourlyRate: 2 },
    { type: 'premium', baseRate: 8, hourlyRate: 4 },
    { type: 'disabled', baseRate: 3, hourlyRate: 1 },
  ],
  selectedSlot: null,
  setSelectedSlot: (slot) => set({ selectedSlot: slot }),
  createReservation: (reservation) => {
    set((state) => ({
      reservations: [
        ...state.reservations,
        {
          ...reservation,
          id: Math.random().toString(36).substr(2, 9),
          status: 'active',
          paymentStatus: 'pending',
        },
      ],
      slots: state.slots.map((slot) =>
        slot.id === reservation.slotId
          ? { ...slot, isReserved: true, reservedBy: reservation.userId }
          : slot
      ),
    }));
  },
  login: async (email, password) => {
    // Simulate API call
    const mockUser: User = {
      id: '1',
      name: 'John Doe',
      email,
      reservations: [],
      role: 'user',
      credits: 100,
    };
    set({ currentUser: mockUser });
  },
  logout: () => set({ currentUser: null }),
}));