import { ParkingSlot } from '../types';

export function generateMockSlots(): ParkingSlot[] {
  const floors = 2;
  const slotsPerFloor = 8;
  const slots: ParkingSlot[] = [];

  for (let floor = 1; floor <= floors; floor++) {
    for (let i = 1; i <= slotsPerFloor; i++) {
      const slotNumber = (floor - 1) * slotsPerFloor + i;
      slots.push({
        id: `slot-${slotNumber}`,
        number: slotNumber,
        isOccupied: Math.random() > 0.7,
        isReserved: false,
        type: i <= 6 ? 'standard' : i === 7 ? 'premium' : 'disabled',
        floor,
      });
    }
  }

  return slots;
}