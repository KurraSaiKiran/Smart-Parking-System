import { differenceInHours } from 'date-fns';
import { ParkingRate } from '../types';

export function calculatePrice(
  startTime: string,
  endTime: string,
  rate: ParkingRate
): number {
  const hours = differenceInHours(new Date(endTime), new Date(startTime));
  return rate.baseRate + Math.max(0, hours) * rate.hourlyRate;
}