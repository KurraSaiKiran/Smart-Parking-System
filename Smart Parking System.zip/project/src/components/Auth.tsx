import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useStore } from '../store/useStore';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

type LoginForm = z.infer<typeof loginSchema>;

export function Auth() {
  const { login, currentUser, logout } = useStore();
  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  });

  if (currentUser) {
    return (
      <div className="flex items-center space-x-4">
        <span className="text-sm">Welcome, {currentUser.name}</span>
        <span className="text-sm text-green-600">Credits: ${currentUser.credits}</span>
        <button
          onClick={logout}
          className="text-sm text-red-600 hover:text-red-800"
        >
          Logout
        </button>
      </div>
    );
  }

  return (
    <form
      onSubmit={handleSubmit((data) => login(data.email, data.password))}
      className="flex space-x-2"
    >
      <div>
        <input
          {...register('email')}
          type="email"
          placeholder="Email"
          className="px-2 py-1 text-sm border rounded"
        />
        {errors.email && (
          <p className="text-xs text-red-500">{errors.email.message}</p>
        )}
      </div>
      <div>
        <input
          {...register('password')}
          type="password"
          placeholder="Password"
          className="px-2 py-1 text-sm border rounded"
        />
        {errors.password && (
          <p className="text-xs text-red-500">{errors.password.message}</p>
        )}
      </div>
      <button
        type="submit"
        className="px-4 py-1 text-sm text-white bg-blue-600 rounded hover:bg-blue-700"
      >
        Login
      </button>
    </form>
  );
}