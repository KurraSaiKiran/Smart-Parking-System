import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ParkingSlot } from '../types';
import { useStore } from '../store/useStore';
import { calculatePrice } from '../utils/pricing';

const reservationSchema = z.object({
  startTime: z.string(),
  endTime: z.string(),
}).refine(
  (data) => new Date(data.startTime) < new Date(data.endTime),
  { message: "End time must be after start time" }
);

type ReservationFormData = z.infer<typeof reservationSchema>;

interface ReservationFormProps {
  selectedSlot: ParkingSlot | null;
  onClose: () => void;
}

export function ReservationForm({ selectedSlot, onClose }: ReservationFormProps) {
  const { currentUser, parkingRates, createReservation } = useStore();
  const { register, handleSubmit, watch, formState: { errors } } = 
    useForm<ReservationFormData>({
      resolver: zodResolver(reservationSchema),
    });

  if (!selectedSlot || !currentUser) return null;

  const rate = parkingRates.find((r) => r.type === selectedSlot.type)!;
  const startTime = watch('startTime');
  const endTime = watch('endTime');
  const price = startTime && endTime ? 
    calculatePrice(startTime, endTime, rate) : 0;

  const onSubmit = (data: ReservationFormData) => {
    createReservation({
      slotId: selectedSlot.id,
      userId: currentUser.id,
      startTime: data.startTime,
      endTime: data.endTime,
      price,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg w-96">
        <h2 className="text-xl font-bold mb-4">
          Reserve Slot {selectedSlot.number} ({selectedSlot.type})
        </h2>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Start Time
            </label>
            <input
              type="datetime-local"
              {...register('startTime')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
            {errors.startTime && (
              <p className="text-xs text-red-500">{errors.startTime.message}</p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">
              End Time
            </label>
            <input
              type="datetime-local"
              {...register('endTime')}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
            />
            {errors.endTime && (
              <p className="text-xs text-red-500">{errors.endTime.message}</p>
            )}
          </div>
          {price > 0 && (
            <div className="bg-gray-50 p-4 rounded">
              <p className="text-sm font-medium text-gray-700">
                Estimated Price: ${price}
              </p>
              <p className="text-xs text-gray-500">
                Base rate: ${rate.baseRate} + ${rate.hourlyRate}/hour
              </p>
            </div>
          )}
          <div className="flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
            >
              Reserve
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}