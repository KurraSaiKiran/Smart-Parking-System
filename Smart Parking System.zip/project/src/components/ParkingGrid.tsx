import React from 'react';
import { ParkingSlot } from '../types';
import { Car, Square, Crown, AccessibilityIcon } from 'lucide-react';
import { useStore } from '../store/useStore';

interface ParkingGridProps {
  slots: ParkingSlot[];
  onSlotClick: (slot: ParkingSlot) => void;
}

export function ParkingGrid({ slots, onSlotClick }: ParkingGridProps) {
  const currentUser = useStore((state) => state.currentUser);

  const getSlotIcon = (slot: ParkingSlot) => {
    if (slot.isOccupied) return <Car className="w-8 h-8 text-red-600" />;
    switch (slot.type) {
      case 'premium':
        return <Crown className="w-8 h-8 text-yellow-600" />;
      case 'disabled':
        return <AccessibilityIcon className="w-8 h-8 text-blue-600" />;
      default:
        return <Square className="w-8 h-8 text-green-600" />;
    }
  };

  return (
    <div className="space-y-8">
      {[...new Set(slots.map((slot) => slot.floor))].map((floor) => (
        <div key={floor} className="space-y-4">
          <h3 className="text-lg font-semibold">Floor {floor}</h3>
          <div className="grid grid-cols-4 gap-4">
            {slots
              .filter((slot) => slot.floor === floor)
              .map((slot) => (
                <button
                  key={slot.id}
                  onClick={() => onSlotClick(slot)}
                  disabled={slot.isOccupied || slot.isReserved || !currentUser}
                  className={`
                    p-6 rounded-lg flex flex-col items-center justify-center
                    ${
                      slot.isOccupied
                        ? 'bg-red-100 cursor-not-allowed'
                        : slot.isReserved
                        ? 'bg-yellow-100'
                        : slot.type === 'premium'
                        ? 'bg-amber-100 hover:bg-amber-200'
                        : slot.type === 'disabled'
                        ? 'bg-blue-100 hover:bg-blue-200'
                        : 'bg-green-100 hover:bg-green-200'
                    }
                    ${!currentUser ? 'opacity-50 cursor-not-allowed' : ''}
                  `}
                >
                  {getSlotIcon(slot)}
                  <span className="mt-2 font-semibold">Slot {slot.number}</span>
                  {slot.isReserved && slot.reservedBy === currentUser?.id && (
                    <span className="text-sm text-yellow-700">Your Reservation</span>
                  )}
                  {slot.type !== 'standard' && (
                    <span className="text-xs text-gray-600 capitalize">
                      {slot.type}
                    </span>
                  )}
                </button>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
}