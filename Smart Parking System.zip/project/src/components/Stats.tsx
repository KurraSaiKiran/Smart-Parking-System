import React from 'react';
import { ParkingSlot } from '../types';
import { CircleDot } from 'lucide-react';

interface StatsProps {
  slots: ParkingSlot[];
}

export function Stats({ slots }: StatsProps) {
  const totalSlots = slots.length;
  const occupiedSlots = slots.filter((slot) => slot.isOccupied).length;
  const reservedSlots = slots.filter((slot) => slot.isReserved).length;
  const availableSlots = totalSlots - occupiedSlots - reservedSlots;

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex items-center">
          <CircleDot className="w-5 h-5 text-blue-500 mr-2" />
          <span className="text-sm text-gray-500">Total Slots</span>
        </div>
        <p className="text-2xl font-bold">{totalSlots}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex items-center">
          <CircleDot className="w-5 h-5 text-green-500 mr-2" />
          <span className="text-sm text-gray-500">Available</span>
        </div>
        <p className="text-2xl font-bold">{availableSlots}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex items-center">
          <CircleDot className="w-5 h-5 text-yellow-500 mr-2" />
          <span className="text-sm text-gray-500">Reserved</span>
        </div>
        <p className="text-2xl font-bold">{reservedSlots}</p>
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="flex items-center">
          <CircleDot className="w-5 h-5 text-red-500 mr-2" />
          <span className="text-sm text-gray-500">Occupied</span>
        </div>
        <p className="text-2xl font-bold">{occupiedSlots}</p>
      </div>
    </div>
  );
}