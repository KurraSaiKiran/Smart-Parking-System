import React from 'react';
import { useStore } from '../store/useStore';
import { format } from 'date-fns';

export function ReservationHistory() {
  const { reservations, currentUser, slots } = useStore();

  if (!currentUser) return null;

  const userReservations = reservations.filter(
    (res) => res.userId === currentUser.id
  );

  if (userReservations.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Your Reservations</h2>
        <p className="text-gray-500">No reservations yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Your Reservations</h2>
      <div className="space-y-4">
        {userReservations.map((reservation) => {
          const slot = slots.find((s) => s.id === reservation.slotId)!;
          return (
            <div
              key={reservation.id}
              className="border rounded-lg p-4 flex justify-between items-center"
            >
              <div>
                <h3 className="font-medium">
                  Slot {slot.number} (Floor {slot.floor})
                </h3>
                <p className="text-sm text-gray-500">
                  {format(new Date(reservation.startTime), 'PPp')} -{' '}
                  {format(new Date(reservation.endTime), 'PPp')}
                </p>
              </div>
              <div className="text-right">
                <p className="font-medium">${reservation.price}</p>
                <span
                  className={`text-xs px-2 py-1 rounded-full ${
                    reservation.status === 'active'
                      ? 'bg-green-100 text-green-800'
                      : reservation.status === 'completed'
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {reservation.status}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}